package Client;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class AdminWindow {
	public static void main(String[] args) {
// Create frame with title Registration Demo
		String url = "jdbc:mysql://localhost:3306/sys";
	    String username = "root";
		String password = "admin2448";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		int active_conn=0;
		   {
	            try {
	               
	                Connection connection=DriverManager.getConnection(url, username, password);
	                active_conn=stmt.executeUpdate("show status where variable_name = 'threads_connected';");
	                
	            } catch (SQLException e1) {
	                e1.printStackTrace();
	            }


	        }
		
		
		JFrame frame = new JFrame();
		frame.setTitle("Ipsilon Networks: Admin Window");
		
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
//		JPanel headingPanel = new JPanel();
//		JLabel headingLabel = new JLabel("Admin Window");
//		headingPanel.add(headingLabel);
		JPanel panel = new JPanel(new GridBagLayout());
// Constraints for the layout
		GridBagConstraints constr = new GridBagConstraints();
		constr.insets = new Insets(5, 5, 5, 5);
		constr.anchor = GridBagConstraints.WEST;
// Setting initial grid values to 0,0
		constr.gridx = 0;
		constr.gridy = 0;
		JLabel registertedUsers = new JLabel("Number of registered users: ");
		JLabel loggedUsers = new JLabel("Number of Users Logged in: ");
		JLabel connectedUsers = new JLabel("Number of Users Connected: ");
		JLabel usersLoggedLabel = new JLabel("Users Logged in: ");
		JLabel usersLockedLabel = new JLabel("Users Locked out: ");
		JTextField nameInput = new JTextField(5);
				JTextField emailInput = new JTextField(5);
		JTextField phoneInput = new JTextField(5);
		JTextArea textArea1 = new JTextArea(5, 20);
		JTextArea textArea2 = new JTextArea(5, 20);
		JScrollPane scrollableUsersLogged = new JScrollPane(textArea1);
		scrollableUsersLogged.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollableUsersLogged.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		JScrollPane scrollableLockedUsers = new JScrollPane(textArea2);
		scrollableLockedUsers.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollableLockedUsers.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		panel.add(registertedUsers, constr);
		constr.gridx = 1;
		panel.add(nameInput, constr);
		constr.gridx = 0;
		constr.gridy = 1;
		panel.add(loggedUsers, constr);
		constr.gridx = 1;
		panel.add(emailInput, constr);
		constr.gridx = 0;
		constr.gridy = 2;
		panel.add(connectedUsers, constr);
		constr.gridx = 1;
		panel.add(phoneInput, constr);
		constr.gridx = 0;
		constr.gridy = 3;
		panel.add(usersLoggedLabel, constr);
		constr.gridx = 1;
		panel.add(scrollableUsersLogged, constr);
		constr.gridx = 0;
		constr.gridy = 4;
		panel.add(usersLockedLabel, constr);
		constr.gridx = 1;
		panel.add(scrollableLockedUsers, constr);
		constr.gridx = 1;
		constr.gridy = 5;
		constr.gridwidth = 2;
		constr.anchor = GridBagConstraints.CENTER;
// Button with text "Register"
//		JButton button = new JButton("Submit");
// add a listener to button
//		button.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				headingLabel.setText("Thanks for Contacting us. We'll get back to you shortly.");
//				nameInput.setText("");
//				emailInput.setText("");
//				phoneInput.setText("");
//				textArea.setText("");
//			}
//		});
//		panel.add(button, constr);
//		mainPanel.add(headingPanel);
		mainPanel.add(panel);
		frame.add(mainPanel);
		frame.pack();
		frame.setSize(500, 500);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
