package Client;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Client extends JFrame
{
	//final variables for frame dimensions
	private final int Width = 500;
	private final int Height = 400;
	
	//variables for each frame and panel
	private TitleInner TitlePanel;
	private MainPageInner MainPanel;
	private LoginInner LoginFrame;
	private RegisterInner RegisterFrame;
	private UnlockInner UnlockFrame;
	private ConnectInner ConnectFrame;
	private String url = "jdbc:mysql://localhost:3306/sys";
    private static String username = "root";
	private static String password = "admin2448";
	final static private String host = "smtp.gmail.com";

	// -- You must have a valid gmail username/password pair to use
	// gmail as a SMTP service
	static private String gusername = "<<your gmail username>>";
	static private String gpassword = "<<your gmail password>>";
	
	public Client()
	{
		//this is the initial frame that appears when code is run.
		super();
		
		setTitle("Ipsilon Networks");
		setSize(Width, Height);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(new Color(245, 229, 193));
		setLayout(new BorderLayout());
		setResizable(false);
		
		//this calls and creates the inner class that holds the title panel
		TitlePanel = new TitleInner();
		this.add(TitlePanel, BorderLayout.NORTH);
		TitlePanel.setVisible(true);	
		
		ConnectFrame = new ConnectInner();
		ConnectFrame.setVisible(true);
		
		setVisible(false);
	}
	
	public class TitleInner extends JPanel
	{	
		//this holds the needed stuff to create the title card that is on
		//each frame and panel
		public TitleInner()
		{
			super();
			this.setBackground(new Color(184, 161, 112));
			JLabel Title = new JLabel("Ipsilon Networks");
			Title.setFont(new Font("Serif", Font.PLAIN, 35));
			this.add(Title);
		}
	}

	public class MainPageInner extends JFrame
	{
		public MainPageInner()
		{
			//this is the needed stuff to create the login frame
			super();
			setTitle("Ipsilon Networks");
			setSize(Width, Height);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(245, 229, 193));
			setLayout(new FlowLayout());
			setResizable(false);
			
			//creates an instance of the title panel and
			//makes it visible
			TitlePanel = new TitleInner();
			this.add(TitlePanel);
			TitlePanel.setPreferredSize(new Dimension(500, 55));
			TitlePanel.setVisible(true);	
			
			//this is the creation of the 3 buttons located on the main page
			//this is the login button that opens the login frame
			JButton LoginButton = new JButton("Login");
			LoginButton.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							//set login frame visible to true and
							//dispose of previous frame
							try 
							{
								LoginFrame = new LoginInner();		
								LoginFrame.setVisible(true);
								dispose();
							}
							catch(Exception e1)
							{
								System.out.println("There was an error, please try again.");
							}
						}
					}
			);
			
			//this is the button that opens the register frame
			JButton RegisterButton = new JButton("Register");
			RegisterButton.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							//set register panel visible to true
							//and dispose of previous frame
							try 
							{
								RegisterFrame = new RegisterInner();		
								RegisterFrame.setVisible(true);
								dispose();
							}
							catch(Exception e1)
							{
								System.out.println("There was an error, please try again.");
							}
						}
					}
			);
			
			//this is the button that opens the unlock frame
			JButton UnlockButton = new JButton("Unlock");
			UnlockButton.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							//set Unlock panel visible to true
							//and dispose of previous frame
							try 
							{
								UnlockFrame = new UnlockInner();		
								UnlockFrame.setVisible(true);
								dispose();
							}
							catch(Exception e1)
							{
								System.out.println("There was an error, please try again.");
							}
						}
					}
			);
			
			JButton DisconnectButton = new JButton("Disconnect");
			DisconnectButton.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							//set connection frame visible to true and
							//dispose of previous frame
							try 
							{
								ConnectFrame = new ConnectInner();
								ConnectFrame.setVisible(true);
								dispose();
							}
							catch(Exception e1)
							{
								System.out.println("There was an error, please try again.");
							}
						}
					}
			);
			
			//this edits the appearance of the text and size of the buttons
			// and then adds them to the panel
			LoginButton.setFont(new Font("Courier", Font.BOLD, 20));
			RegisterButton.setFont(new Font("Courier", Font.BOLD, 20));
			UnlockButton.setFont(new Font("Courier", Font.BOLD, 20));
			DisconnectButton.setFont(new Font("Courier", Font.BOLD, 20));


			LoginButton.setPreferredSize(new Dimension(240, 70));
			RegisterButton.setPreferredSize(new Dimension(240, 70));
			UnlockButton.setPreferredSize(new Dimension(240, 70));
			DisconnectButton.setPreferredSize(new Dimension(240, 70));
			
			this.add(LoginButton);
			this.add(RegisterButton);
			this.add(UnlockButton);
			this.add(DisconnectButton);
		}
	}
	
	public class LoginInner extends JFrame
	{
		public LoginInner()
		{
			//this is the needed stuff to create the login frame
			super();
			setTitle("Ipsilon Networks");
			setSize(Width, Height);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(245, 229, 193));
			setLayout(new FlowLayout());
			setResizable(false);
			
			//creates an instance of the title panel and
			//makes it visible
			TitlePanel = new TitleInner();
			this.add(TitlePanel);
			TitlePanel.setPreferredSize(new Dimension(500, 55));
			TitlePanel.setVisible(true);	
			
			//this is a menu button that creates a new instance of the client() 
			//constructor and disposes of the previous frame
			//Essentially it recreates the main page for navigation 
			JButton MenuButton = new JButton("Menu");
			MenuButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						MainPanel = new MainPageInner();
						MainPanel.setVisible(true);
						dispose();
					}
				}
			);
			MenuButton.setPreferredSize(new Dimension(450, 55));
			MenuButton.setFont(new Font("Courier", Font.BOLD, 15));
			
			this.add(MenuButton);
			
			//these are text boxes used for entering usernames and passwords
			JTextField UsernameBox = new JTextField("Username");
			UsernameBox.setPreferredSize(new Dimension(450,55));
			this.add(UsernameBox);
		
			JPasswordField PasswordBox = new JPasswordField("Password");
			PasswordBox.setPreferredSize(new Dimension(450,55));
			this.add(PasswordBox);
			
			//this button reads what was inputed from the text boxes and 
			//processes it
			JButton SignInButton = new JButton("Sign In");
			SignInButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						//This part here is where i believe we would put the code to
						//process the login details
						
//						String userField = UsernameBox.getText();
//						//System.out.println(userField);
//						
//						String passField = PasswordBox.getText();
//						//System.out.println(passField); if(e.getSource()==RegisterButton)
				        {
				            try {
				               
				                Connection connection=DriverManager.getConnection(url, username, password);
				               
				                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE username= ? and password = ?") ;
				                    preparedStatement.setString(1, UsernameBox.getText());
				                    preparedStatement.setString(2, PasswordBox.getText());
				                    ResultSet resultSet = preparedStatement.executeQuery();
				                    
				                    if (resultSet.next()) {
				                        JOptionPane.showMessageDialog(null, "You have successfully logged in");
				                    } else {
				                        JOptionPane.showMessageDialog(null, "Wrong Username & Password");
				                    }
				            } catch (SQLException e1) {
				                e1.printStackTrace();
				            }


				        }
						
						
						
						
					}
				}
			);
			SignInButton.setPreferredSize(new Dimension(450, 55));
			SignInButton.setFont(new Font("Courier", Font.BOLD, 15));
			this.add(SignInButton);
		}
	}
	
	public class RegisterInner extends JFrame
	{
		public RegisterInner()
		{
			//this is the stuff needed to create the frame
			super();
			setTitle("Ipsilon Networks");
			setSize(Width, Height);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(245, 229, 193));
			setLayout(new FlowLayout());
			setResizable(false);
			
			
			//creates the title panel
			TitlePanel = new TitleInner();
			this.add(TitlePanel);
			TitlePanel.setPreferredSize(new Dimension(500, 55));
			TitlePanel.setVisible(true);	
			
			
			//this is a menu button that creates a new instance of the client() 
			//constructor and disposes of the previous frame
			//Essentially it recreates the main page for navigation
			JButton MenuButton = new JButton("Menu");
			MenuButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						MainPanel = new MainPageInner();
						MainPanel.setVisible(true);
						dispose();
					}
				}
			);
			MenuButton.setPreferredSize(new Dimension(450, 55));
			MenuButton.setFont(new Font("Courier", Font.BOLD, 15));
			
			this.add(MenuButton);
			
			//this is the text boxes for username, password and email
			JTextField UsernameBox = new JTextField("Username");
			UsernameBox.setPreferredSize(new Dimension(450,55));
			this.add(UsernameBox);
		
			JPasswordField PasswordBox = new JPasswordField("Password");
			PasswordBox.setPreferredSize(new Dimension(450,55));
			this.add(PasswordBox);
			
//			JPasswordField ConfirmPasswordBox = new JPasswordField("Confirm Password");
//			PasswordBox.setPreferredSize(new Dimension(450,55));
//			this.add(ConfirmPasswordBox);
			
			JTextField EmailBox = new JTextField("Email");
			EmailBox.setPreferredSize(new Dimension(450,55));
			this.add(EmailBox);
			
			
			//this button reads what was inputed from the text boxes and 
			//processes it
			JButton RegisterButton = new JButton("Register");
			RegisterButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						 if(e.getSource()==RegisterButton)
					        {
					            try {
					               
					                Connection connection=DriverManager.getConnection(url, username, password);
					               
					                PreparedStatement Pstatement=connection.prepareStatement("insert into users values(?,?,?,?)");
					               
					                Pstatement.setString(1,UsernameBox.getText());
					                Pstatement.setString(2,PasswordBox.getText());
					                //Pstatement.setString(3,ConfirmPasswordBox.getText());
					                Pstatement.setString(3,EmailBox.getText());
					                Pstatement.setInt(4,0);
					               
//					                if(PasswordBox.getText().equalsIgnoreCase(ConfirmPasswordBox.getText()))
//					                {
					                    
					                    Pstatement.executeUpdate();
					                    JOptionPane.showMessageDialog(null,"Data Registered Successfully");
//					                }
//					                else
//					                {
//					                    JOptionPane.showMessageDialog(null,"password did not match");
//					                }

					            } catch (SQLException e1) {
					                e1.printStackTrace();
					            }


					        }
//					        if(e.getSource()==resetButton)
//					        {
//					           
//					            usernameTextField.setText("");
//
//					            passwordField.setText("");
//					            confirmPasswordField.setText("");
//
//					            emailTextField.setText("");
//					        }
					}
				}
			);
			RegisterButton.setPreferredSize(new Dimension(450, 55));
			RegisterButton.setFont(new Font("Courier", Font.BOLD, 15));
			this.add(RegisterButton);
		}
	}
	
	public class UnlockInner extends JFrame
	{
		public UnlockInner()
		{
			//this is the stuff needed for frame
			super();
			setTitle("Ipsilon Networks");
			setSize(Width, Height);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(245, 229, 193));
			setLayout(new FlowLayout());
			setResizable(false);
			
			//creates the title panel
			TitlePanel = new TitleInner();
			this.add(TitlePanel);
			TitlePanel.setPreferredSize(new Dimension(500, 55));
			TitlePanel.setVisible(true);	
			
			//this is a menu button that creates a new instance of the client() 
			//constructor and disposes of the previous frame
			//Essentially it recreates the main page for navigation
			JButton MenuButton = new JButton("Menu");
			MenuButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						MainPanel = new MainPageInner();
						MainPanel.setVisible(true);
						dispose();
					}
				}
			);
			MenuButton.setPreferredSize(new Dimension(450, 55));
			MenuButton.setFont(new Font("Courier", Font.BOLD, 15));
			
			this.add(MenuButton);
			
			//this creates text boxes for username and email
			JTextField UsernameBox = new JTextField("Username");
			UsernameBox.setPreferredSize(new Dimension(450,55));
			this.add(UsernameBox);
			
			JTextField EmailBox = new JTextField("Email");
			EmailBox.setPreferredSize(new Dimension(450,55));
			this.add(EmailBox);
			
			
			//this button reads what was inputed from the text boxes and 
			//processes it
			JButton UnlockButton = new JButton("Unlock");
			UnlockButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						//This part here is where i believe we would put the code to
						//process the login details
						
//						String userField = UsernameBox.getText();
//						System.out.println(userField);
						String emailField = EmailBox.getText();
//						System.out.println(emailField);
		               
						Properties props = new Properties();
						props.put("mail.smtp.auth", "true");
						props.put("mail.smtp.starttls.enable", "true");
						props.put("mail.smtp.host", host);
						props.put("mail.smtp.port", "587");
						
						Session session = Session.getInstance(props,
								new javax.mail.Authenticator() {
									protected PasswordAuthentication getPasswordAuthentication() {
										return new PasswordAuthentication(gusername, gpassword);
									}
								});
						
						String from = "ssalve@callutheran.edu";
						String to = emailField ;
						try {
							// -- Create a default MimeMessage object.
							Message message = new MimeMessage(session);

							// -- Set From: header field of the header.
							message.setFrom(new InternetAddress(from));

							// -- Set To: header field of the header.
							message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));

							// -- Set Subject: header field
							message.setSubject("CSC335 Project");

							// Now set the actual message
							message.setText("This is the message.\nThis is the message.\nThis is the message.\n");

							// -- Send message
							// -- use either these three lines or...
							// Transport t = session.getTransport("smtp");
							// t.connect();
							// t.sendMessage(message, message.getAllRecipients());
							
							// -- .. this one (which ultimately calls sendMessage(...)
							Transport.send(message);

							System.out.println("Sent message successfully....");

						} catch (MessagingException e1) {
							throw new RuntimeException(e1);
						}
					}
				}
			);
			UnlockButton.setPreferredSize(new Dimension(450, 55));
			UnlockButton.setFont(new Font("Courier", Font.BOLD, 15));
			this.add(UnlockButton);
		}
	}
	
	public class ConnectInner extends JFrame
	{
		public ConnectInner()
		{
			//this is the stuff needed for frame
			super();
			setTitle("Ipsilon Networks");
			setSize(Width, Height);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(245, 229, 193));
			setLayout(new FlowLayout());
			setResizable(false);
			
			//creates the title panel
			TitlePanel = new TitleInner();
			this.add(TitlePanel);
			TitlePanel.setPreferredSize(new Dimension(500, 55));
			TitlePanel.setVisible(true);	
			
			JTextField IPBox = new JTextField("IP");
			IPBox.setPreferredSize(new Dimension(450,55));
			this.add(IPBox);
			
			//this button reads what was inputed from the text boxes and 
			//processes it
			JButton ConnectButton = new JButton("Connect");
			ConnectButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						//This part here is where i believe we would put the code to
						//process the Connection Details
						String IPField = IPBox.getText();
						System.out.println(IPField);
						MainPanel = new MainPageInner();
						MainPanel.setVisible(true);
						dispose();
					}
				}
			);
			ConnectButton.setPreferredSize(new Dimension(450, 55));
			ConnectButton.setFont(new Font("Courier", Font.BOLD, 15));
			this.add(ConnectButton);
		}
	}
	
	public static void main(String args[])
	{
		new Client();
		DBaseConnection dbc = new DBaseConnection();
	//	dbc.accessDatabase();
	}
}